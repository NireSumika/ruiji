#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @Description
* @Auther Terence Zhang
* @Datetime ${DATE} ${TIME}

**/
public class ${NAME} {
}
